/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/changelog/changelog.js":
/*!************************************!*\
  !*** ./src/changelog/changelog.js ***!
  \************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _changelog_migration1Fn_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../changelog/migration1Fn.js */ "./src/changelog/migration1Fn.js");
/* harmony import */ var _changelog_migration2Fn_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../changelog/migration2Fn.js */ "./src/changelog/migration2Fn.js");
/* harmony import */ var _changelog_migration3Fn_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../changelog/migration3Fn.js */ "./src/changelog/migration3Fn.js");
/* harmony import */ var _changelog_migration4Fn_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../changelog/migration4Fn.js */ "./src/changelog/migration4Fn.js");




const changelog = [{
  name: 'migration1Fn',
  migrationFn: _changelog_migration1Fn_js__WEBPACK_IMPORTED_MODULE_0__["default"]
}, {
  name: 'migration2Fn',
  migrationFn: _changelog_migration2Fn_js__WEBPACK_IMPORTED_MODULE_1__["default"]
}, {
  name: 'migration3Fn',
  migrationFn: _changelog_migration3Fn_js__WEBPACK_IMPORTED_MODULE_2__["default"]
}, {
  name: 'migration4Fn',
  migrationFn: _changelog_migration4Fn_js__WEBPACK_IMPORTED_MODULE_3__["default"]
}];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (changelog);

/***/ }),

/***/ "./src/changelog/migrateFn.js":
/*!************************************!*\
  !*** ./src/changelog/migrateFn.js ***!
  \************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _changelog_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./changelog.js */ "./src/changelog/changelog.js");
/* harmony import */ var _lib_migration_migration_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/migration/migration.js */ "./src/lib/migration/migration.js");


const migrateFn = async config => {
  console.debug('start migration config', config);
  console.debug('start migration changelog', _changelog_js__WEBPACK_IMPORTED_MODULE_0__["default"]);
  const migratedConfig = await (0,_lib_migration_migration_js__WEBPACK_IMPORTED_MODULE_1__["default"])(config, _changelog_js__WEBPACK_IMPORTED_MODULE_0__["default"]);
  console.debug('stop migration', migratedConfig);
  return migratedConfig;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migrateFn);

/***/ }),

/***/ "./src/changelog/migration1Fn.js":
/*!***************************************!*\
  !*** ./src/changelog/migration1Fn.js ***!
  \***************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants.js */ "./src/constants.js");

const migration1Fn = async config => {
  config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.firstStart] = true;
  config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.extensionUuid] = crypto.randomUUID();
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migration1Fn);

/***/ }),

/***/ "./src/changelog/migration2Fn.js":
/*!***************************************!*\
  !*** ./src/changelog/migration2Fn.js ***!
  \***************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants.js */ "./src/constants.js");

const migration2Fn = async config => {
  const options = config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.options];
  if (options.length === 1 && options[0].name === undefined) {
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.name] = 'common';
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.commandTemplate] = 'aria2 -c -s4 --max-tries=0 %h %u';
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migration2Fn);

/***/ }),

/***/ "./src/changelog/migration3Fn.js":
/*!***************************************!*\
  !*** ./src/changelog/migration3Fn.js ***!
  \***************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants.js */ "./src/constants.js");

const migration3Fn = async config => {
  const options = config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.options];
  if (options.length === 1 && options[0].name === 'common') {
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.commandTemplate] = 'aria2 -c -s4 -m0 %h %u';
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migration3Fn);

/***/ }),

/***/ "./src/changelog/migration4Fn.js":
/*!***************************************!*\
  !*** ./src/changelog/migration4Fn.js ***!
  \***************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants.js */ "./src/constants.js");

const migration4Fn = async config => {
  const options = config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.options];
  if (options.length === 1 && options[0].name === 'common') {
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.commandTemplate] = 'aria2c -c -s4 -m0 -k1M --stream-piece-selector=inorder --summary-interval=1 --console-log-level=notice %h %u';
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.useDisallowedHeaders] = true;
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.disallowedHeaders] = ['Range'];
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migration4Fn);

/***/ }),

/***/ "./src/constants.js":
/*!**************************!*\
  !*** ./src/constants.js ***!
  \**************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const Constants = Object.freeze({
  option: Object.freeze({
    options: 'options',
    firstStart: 'firstStart',
    extensionUuid: 'extensionUuid',
    tabIdUrlParameterName: prefix => `${prefix}tabId`,
    frameIdUrlParameterName: prefix => `${prefix}frameId`,
    urlPattern: 'urlPattern',
    urlPatternFlags: 'urlPatternFlags',
    useHeaders: 'useHeaders',
    name: 'name',
    headerParameterName: 'headerParameterName',
    useAllowedHeaders: 'useAllowedHeaders',
    allowedHeaders: 'allowedHeaders',
    useDisallowedHeaders: 'useDisallowedHeaders',
    disallowedHeaders: 'disallowedHeaders',
    commandTemplate: 'commandTemplate',
    escapeCmdUniversal: {
      escapeCmdUniversal: 'escapeCmdUniversal',
      enabled: 'enabled',
      platforms: 'platforms'
    }
  }),
  messageType: {
    execProbRequest: 'exec-prob-request',
    copyDownloadCommand: 'copy-download-command',
    copyDownloadCommandInBackground: 'copy-download-command-in-background'
  },
  element: Object.freeze({
    contextMenuId: "simple-copy-aria2-download-command",
    config: 'config',
    reset: 'reset',
    save: 'save'
  }),
  changelog: 'changelog'
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Constants);

/***/ }),

/***/ "./src/lib/Option.js":
/*!***************************!*\
  !*** ./src/lib/Option.js ***!
  \***************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Option)
/* harmony export */ });
class Option {
  #config = null;
  #storage = browser.storage.local;
  #defaultConfigPath;
  constructor(defaultConfigPath = '/config.json') {
    this.#defaultConfigPath = defaultConfigPath;
    this.#cacheReset();
  }
  async get() {
    if (!this.#config) {
      this.#config = await this.#storage.get();
      if (!this.#config || Object.keys(this.#config).length < 1) {
        await this.reset();
      }
    }
    return structuredClone(this.#config);
  }
  async save(config) {
    await this.#storage.set(config);
    this.#config = config;
  }
  async reset() {
    const config = await (await fetch(browser.runtime.getURL(this.#defaultConfigPath))).json();
    await this.#storage.set(config);
    this.#config = config;
  }
  #cacheReset() {
    browser.storage.onChanged.addListener(() => this.#config = null);
  }
}

/***/ }),

/***/ "./src/lib/escapeCmdUniversal.js":
/*!***************************************!*\
  !*** ./src/lib/escapeCmdUniversal.js ***!
  \***************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PLATFORM: () => (/* binding */ PLATFORM),
/* harmony export */   escapeCmdUniversal: () => (/* binding */ escapeCmdUniversal)
/* harmony export */ });
const PLATFORM = Object.freeze({
  AUTO: 'AUTO',
  OFF: 'OFF',
  WINDOWS: 'WINDOWS',
  LINUX: 'LINUX'
});
const escapeCmdUniversal = (str, platforms = [PLATFORM.AUTO]) => {
  if (platforms.length < 1 || platforms.includes(PLATFORM.OFF)) {
    console.debug('escapeCmdUniversal is off');
    return str;
  }
  console.debug('escapeCmdUniversal is on for:', platforms);
  if (platforms.includes(PLATFORM.AUTO) || platforms.includes(PLATFORM.WINDOWS) && navigator.platform.indexOf('Win') >= 0) {
    console.debug('escapeCmdUniversal current platform is:', PLATFORM.WINDOWS);
    return str.replace(/%/g, '%%').replace(/([&<>|^"()!])/g, '^$1');
  } else if (platforms.includes(PLATFORM.AUTO) || platforms.includes(PLATFORM.LINUX)) {
    console.debug('escapeCmdUniversal current platform is:', PLATFORM.LINUX);
    return `'${str.replace(/'/g, `'\\''`)}'`;
  }
};


/***/ }),

/***/ "./src/lib/getUrlByTabIdAndFrameId.js":
/*!********************************************!*\
  !*** ./src/lib/getUrlByTabIdAndFrameId.js ***!
  \********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const getUrlByTabIdAndFrameIdFn = async (tabId, frameId) => {
  if (frameId < 1) {
    const tabs = await browser.tabs.get(tabId);
    if (tabs.length > 0) {
      return tabs[0].url;
    } else {
      console.warn("tab was not found " + tabId);
    }
  }
  const {
    url
  } = (await browser.webNavigation.getAllFrames({
    tabId
  })).find(frame => frame.frameId === frameId);
  return url;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getUrlByTabIdAndFrameIdFn);

/***/ }),

/***/ "./src/lib/migration/checkOrInitFn.js":
/*!********************************************!*\
  !*** ./src/lib/migration/checkOrInitFn.js ***!
  \********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const checkOrInitFn = (config, migrationScriptName, changelogName) => {
  const configChangelog = config[changelogName];
  if (configChangelog === undefined) {
    config[changelogName] = {};
    return false;
  }
  const configChangelogMigrationScript = configChangelog[migrationScriptName];
  return configChangelogMigrationScript === undefined || configChangelogMigrationScript === false;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (checkOrInitFn);

/***/ }),

/***/ "./src/lib/migration/constants.js":
/*!****************************************!*\
  !*** ./src/lib/migration/constants.js ***!
  \****************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const Constants = Object.freeze({
  changelog: 'changelog'
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Constants);

/***/ }),

/***/ "./src/lib/migration/migration.js":
/*!****************************************!*\
  !*** ./src/lib/migration/migration.js ***!
  \****************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _migrationHelperFn_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./migrationHelperFn.js */ "./src/lib/migration/migrationHelperFn.js");

const startMigrationFn = async (originalConfig, changelog) => {
  const config = {
    ...originalConfig
  };
  console.debug('start migration', {
    changelog,
    config
  });
  for (const {
    name,
    migrationFn
  } of changelog) {
    console.debug('start migration file', {
      config,
      name,
      migrationFn
    });
    await (0,_migrationHelperFn_js__WEBPACK_IMPORTED_MODULE_0__["default"])(config, name, migrationFn);
  }
  console.debug('stop migration', {
    originalConfig,
    config
  });
  return config;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (startMigrationFn);

/***/ }),

/***/ "./src/lib/migration/migrationHelperFn.js":
/*!************************************************!*\
  !*** ./src/lib/migration/migrationHelperFn.js ***!
  \************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants.js */ "./src/lib/migration/constants.js");
/* harmony import */ var _checkOrInitFn_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./checkOrInitFn.js */ "./src/lib/migration/checkOrInitFn.js");


const migrationHelperFn = async (config, migrationScriptName, migrationFn) => {
  if ((0,_checkOrInitFn_js__WEBPACK_IMPORTED_MODULE_1__["default"])(config, migrationScriptName, _constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].changelog)) {
    config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].changelog][migrationScriptName] = true;
    await migrationFn(config);
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migrationHelperFn);

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!***************************!*\
  !*** ./src/background.js ***!
  \***************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_Option_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./lib/Option.js */ "./src/lib/Option.js");
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants.js */ "./src/constants.js");
/* harmony import */ var _lib_getUrlByTabIdAndFrameId_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lib/getUrlByTabIdAndFrameId.js */ "./src/lib/getUrlByTabIdAndFrameId.js");
/* harmony import */ var _lib_escapeCmdUniversal_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lib/escapeCmdUniversal.js */ "./src/lib/escapeCmdUniversal.js");
/* harmony import */ var _changelog_migrateFn_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./changelog/migrateFn.js */ "./src/changelog/migrateFn.js");





const option = new _lib_Option_js__WEBPACK_IMPORTED_MODULE_0__["default"]();
browser.runtime.onInstalled.addListener(async ({
  reason
}) => {
  if (reason === 'install' || reason === 'update') {
    console.debug('It is the first installation or update, the extension config will be migrated');
    const config = await (0,_changelog_migrateFn_js__WEBPACK_IMPORTED_MODULE_4__["default"])(await option.get());
    if (reason === 'install') {
      console.debug('It is the first installation, the extension uuid will be generated');
      config[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.extensionUuid] = crypto.randomUUID();
      console.debug('It is the first installation, the extension uuid was generated', config[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.extensionUuid]);
    }
    await option.save(config);
    console.debug('Migration is completed, old context menu will be removed');
    await browser.contextMenus.removeAll();
    console.debug('Migration is completed, old context menu was removed');
    console.debug('New context menu will be added');
    browser.contextMenus.create({
      id: _constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].element.contextMenuId,
      title: browser.i18n.getMessage("contextMenuTitle"),
      contexts: ["link", "image", "video", "audio"]
    });
    console.debug('New context menu was added');
  }
});
browser.contextMenus.onClicked.addListener(({
  menuItemId,
  linkUrl,
  frameId,
  srcUrl,
  mediaType
}, {
  id: tabId
}) => {
  if (menuItemId !== _constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].element.contextMenuId) {
    return;
  }
  console.debug('current contextMenus.onClicked is', {
    menuItemId,
    linkUrl,
    frameId,
    srcUrl,
    mediaType
  }, {
    id: tabId
  });
  if (mediaType === undefined) {
    // treat undefined as a link
    mediaType = 'link';
  }
  if (["image", "video", "audio"].includes(mediaType)) {
    linkUrl = srcUrl;
  }
  console.debug('send', _constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].messageType.execProbRequest);
  console.debug('send linkUrl', linkUrl);
  browser.tabs.sendMessage(tabId, {
    type: _constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].messageType.execProbRequest,
    payload: {
      linkUrl,
      frameId,
      tabId,
      mediaType
    }
  }, {
    frameId
  });
});
const handleProbRequestFn = async ({
  url,
  requestHeaders,
  method
}) => {
  if (method !== 'GET') {
    return {};
  }
  url = new URL(url);
  const {
    searchParams
  } = url;
  const config = await option.get();
  const urlParameterName = config[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.extensionUuid];
  if (!searchParams.has(urlParameterName)) {
    return {};
  }
  console.debug('{url, requestHeaders, method}', {
    url,
    requestHeaders,
    method
  });
  console.debug('urlParameterName', urlParameterName);
  const tabIdUrlParameterName = _constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.tabIdUrlParameterName(urlParameterName);
  const frameIdUrlParameterName = _constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.frameIdUrlParameterName(urlParameterName);
  const tabId = Number(searchParams.get(tabIdUrlParameterName));
  const frameId = Number(searchParams.get(frameIdUrlParameterName));
  searchParams.delete(urlParameterName);
  searchParams.delete(tabIdUrlParameterName);
  searchParams.delete(frameIdUrlParameterName);
  const urlString = url.toString();
  const domainUrl = await (0,_lib_getUrlByTabIdAndFrameId_js__WEBPACK_IMPORTED_MODULE_2__["default"])(tabId, frameId);
  console.debug('domainUrl', domainUrl);
  const urlOption = config[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.options].find(({
    urlPattern,
    urlPatternFlags
  }) => new RegExp(urlPattern, urlPatternFlags).test(domainUrl));
  if (urlOption === undefined) {
    return {
      cancel: true
    };
  }
  console.debug('config', config);
  console.debug('urlOption', urlOption);
  let command = urlOption[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.commandTemplate];
  if (Boolean(urlOption[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.useHeaders])) {
    if (Boolean(urlOption[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.useDisallowedHeaders])) {
      const disallowedHeaders = urlOption[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.disallowedHeaders] || [];
      console.debug('disallowedHeaders', disallowedHeaders);
      requestHeaders = requestHeaders.filter(({
        name
      }) => !disallowedHeaders.includes(name));
    }
    if (Boolean(urlOption[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.useAllowedHeaders])) {
      const allowedHeaders = urlOption[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.allowedHeaders] || [];
      console.debug('AllowedHeaders', allowedHeaders);
      requestHeaders = requestHeaders.filter(({
        name
      }) => allowedHeaders.includes(name));
    }
    const headerParameterName = urlOption[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.headerParameterName];
    const headers = requestHeaders.map(({
      name,
      value
    }) => `${headerParameterName}="${name}: ${value}"`).join(" ");
    command = command.replace("%h", headers);
  } else {
    command = command.replace("%h", '');
  }
  const escapeOption = urlOption[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.escapeCmdUniversal.escapeCmdUniversal];
  let escapedCmd;
  if (escapeOption !== undefined && Boolean(escapeOption[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.escapeCmdUniversal.enabled])) {
    const platforms = escapeOption[_constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].option.escapeCmdUniversal.platforms];
    const currentPlatforms = platforms.length > 0 ? platforms : [_lib_escapeCmdUniversal_js__WEBPACK_IMPORTED_MODULE_3__.PLATFORM.AUTO];
    escapedCmd = (0,_lib_escapeCmdUniversal_js__WEBPACK_IMPORTED_MODULE_3__.escapeCmdUniversal)(urlString, currentPlatforms);
  } else {
    escapedCmd = urlString;
  }
  console.debug('escapedCmd', escapedCmd);
  command = command.replace("%u", escapedCmd);
  console.debug('command', command);
  console.debug('tabId', tabId);
  console.debug('frameId', frameId);
  browser.tabs.sendMessage(tabId, {
    type: _constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].messageType.copyDownloadCommand,
    payload: {
      command
    }
  }, {
    frameId
  });
  return {
    cancel: true
  };
};
browser.webRequest.onBeforeSendHeaders.addListener(async ({
  url,
  requestHeaders,
  method
}) => {
  try {
    return await handleProbRequestFn({
      url,
      requestHeaders,
      method
    });
  } catch (e) {
    console.debug('error', e);
    return {};
  }
}, {
  urls: ["<all_urls>"]
}, ["blocking", "requestHeaders"]);
browser.runtime.onMessage.addListener(async ({
  type,
  payload: {
    command
  }
}) => {
  if (type !== _constants_js__WEBPACK_IMPORTED_MODULE_1__["default"].messageType.copyDownloadCommandInBackground) {
    return;
  }
  console.debug('copy command in background', {
    type,
    payload: {
      command
    }
  });
  await navigator.clipboard.writeText(command);
  console.debug('command was copied in background', {
    type,
    payload: {
      command
    }
  });
});
})();

/******/ })()
;
//# sourceMappingURL=background.js.map