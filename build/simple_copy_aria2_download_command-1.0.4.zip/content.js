/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/constants.js":
/*!**************************!*\
  !*** ./src/constants.js ***!
  \**************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const Constants = Object.freeze({
  option: Object.freeze({
    options: 'options',
    firstStart: 'firstStart',
    extensionUuid: 'extensionUuid',
    tabIdUrlParameterName: prefix => `${prefix}tabId`,
    frameIdUrlParameterName: prefix => `${prefix}frameId`,
    urlPattern: 'urlPattern',
    urlPatternFlags: 'urlPatternFlags',
    useHeaders: 'useHeaders',
    name: 'name',
    headerParameterName: 'headerParameterName',
    useAllowedHeaders: 'useAllowedHeaders',
    allowedHeaders: 'allowedHeaders',
    useDisallowedHeaders: 'useDisallowedHeaders',
    disallowedHeaders: 'disallowedHeaders',
    commandTemplate: 'commandTemplate',
    escapeCmdUniversal: {
      escapeCmdUniversal: 'escapeCmdUniversal',
      enabled: 'enabled',
      platforms: 'platforms'
    }
  }),
  messageType: {
    execProbRequest: 'exec-prob-request',
    copyDownloadCommand: 'copy-download-command',
    copyDownloadCommandInBackground: 'copy-download-command-in-background'
  },
  element: Object.freeze({
    contextMenuId: "simple-copy-aria2-download-command",
    config: 'config',
    reset: 'reset',
    save: 'save'
  }),
  changelog: 'changelog'
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Constants);

/***/ }),

/***/ "./src/lib/Option.js":
/*!***************************!*\
  !*** ./src/lib/Option.js ***!
  \***************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Option)
/* harmony export */ });
class Option {
  #config = null;
  #storage = browser.storage.local;
  #defaultConfigPath;
  constructor(defaultConfigPath = '/config.json') {
    this.#defaultConfigPath = defaultConfigPath;
    this.#cacheReset();
  }
  async get() {
    if (!this.#config) {
      this.#config = await this.#storage.get();
      if (!this.#config || Object.keys(this.#config).length < 1) {
        await this.reset();
      }
    }
    return structuredClone(this.#config);
  }
  async save(config) {
    await this.#storage.set(config);
    this.#config = config;
  }
  async reset() {
    const config = await (await fetch(browser.runtime.getURL(this.#defaultConfigPath))).json();
    await this.#storage.set(config);
    this.#config = config;
  }
  #cacheReset() {
    browser.storage.onChanged.addListener(() => this.#config = null);
  }
}

/***/ }),

/***/ "./src/lib/sendGetVia.js":
/*!*******************************!*\
  !*** ./src/lib/sendGetVia.js ***!
  \*******************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const typeNames = new Map(Object.entries({
  link: {
    name: 'a',
    link: 'href'
  },
  image: {
    name: 'img',
    link: 'src'
  },
  audio: {
    name: 'audio',
    link: 'src'
  },
  video: {
    name: 'video',
    link: 'src'
  }
}));
const sendGetVia = (mediaType, url) => {
  console.debug('params:', {
    mediaType,
    url
  });
  const {
    name,
    link
  } = typeNames.get(mediaType);
  console.debug('found typeName', {
    name,
    link
  });
  const element = document.createElement(name);
  element[link] = url;
  element.style.display = 'none';
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sendGetVia);

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!************************!*\
  !*** ./src/content.js ***!
  \************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants.js */ "./src/constants.js");
/* harmony import */ var _lib_Option_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lib/Option.js */ "./src/lib/Option.js");
/* harmony import */ var _lib_sendGetVia_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lib/sendGetVia.js */ "./src/lib/sendGetVia.js");



const option = new _lib_Option_js__WEBPACK_IMPORTED_MODULE_1__["default"]();
browser.runtime.onMessage.addListener(async ({
  type,
  payload: {
    linkUrl,
    tabId,
    frameId,
    mediaType
  }
}) => {
  if (type !== _constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].messageType.execProbRequest) {
    return;
  }
  console.debug('start prob req', _constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].messageType.execProbRequest);
  console.debug('linkUrl', linkUrl);
  let url;
  try {
    url = new URL(linkUrl);
  } catch (e) {
    console.debug('url', url);
    console.error(e);
  }
  console.debug('OPTION', option);
  const config = await option.get();
  console.debug('config', config);
  const urlParameterName = config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.extensionUuid];
  const tabIdUrlParameterName = _constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.tabIdUrlParameterName(urlParameterName);
  const frameIdUrlParameterName = _constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.frameIdUrlParameterName(urlParameterName);
  url.searchParams.append(urlParameterName, '');
  url.searchParams.append(tabIdUrlParameterName, tabId);
  url.searchParams.append(frameIdUrlParameterName, frameId);
  console.debug('send prob', url);
  (0,_lib_sendGetVia_js__WEBPACK_IMPORTED_MODULE_2__["default"])(mediaType, url.toString());
});
browser.runtime.onMessage.addListener(({
  type,
  payload: {
    command
  }
}) => {
  if (type !== _constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].messageType.copyDownloadCommand) {
    return;
  }
  console.debug('command', command);
  try {
    navigator.clipboard.writeText(command);
  } catch (e) {
    console.warn('Somewhat writeText does not work in content script', e);
    console.debug('command will be sent to background to copy', command);
    browser.runtime.sendMessage({
      type: _constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].messageType.copyDownloadCommandInBackground,
      payload: {
        command
      }
    });
  }
});
})();

/******/ })()
;
//# sourceMappingURL=content.js.map