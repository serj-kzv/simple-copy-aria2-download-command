/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/changelog/changelog.js":
/*!************************************!*\
  !*** ./src/changelog/changelog.js ***!
  \************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _changelog_migration1Fn_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../changelog/migration1Fn.js */ "./src/changelog/migration1Fn.js");
/* harmony import */ var _changelog_migration2Fn_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../changelog/migration2Fn.js */ "./src/changelog/migration2Fn.js");
/* harmony import */ var _changelog_migration3Fn_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../changelog/migration3Fn.js */ "./src/changelog/migration3Fn.js");
/* harmony import */ var _changelog_migration4Fn_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../changelog/migration4Fn.js */ "./src/changelog/migration4Fn.js");




const changelog = [{
  name: 'migration1Fn',
  migrationFn: _changelog_migration1Fn_js__WEBPACK_IMPORTED_MODULE_0__["default"]
}, {
  name: 'migration2Fn',
  migrationFn: _changelog_migration2Fn_js__WEBPACK_IMPORTED_MODULE_1__["default"]
}, {
  name: 'migration3Fn',
  migrationFn: _changelog_migration3Fn_js__WEBPACK_IMPORTED_MODULE_2__["default"]
}, {
  name: 'migration4Fn',
  migrationFn: _changelog_migration4Fn_js__WEBPACK_IMPORTED_MODULE_3__["default"]
}];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (changelog);

/***/ }),

/***/ "./src/changelog/migrateFn.js":
/*!************************************!*\
  !*** ./src/changelog/migrateFn.js ***!
  \************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _changelog_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./changelog.js */ "./src/changelog/changelog.js");
/* harmony import */ var _lib_migration_migration_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/migration/migration.js */ "./src/lib/migration/migration.js");


const migrateFn = async config => {
  console.debug('start migration config', config);
  console.debug('start migration changelog', _changelog_js__WEBPACK_IMPORTED_MODULE_0__["default"]);
  const migratedConfig = await (0,_lib_migration_migration_js__WEBPACK_IMPORTED_MODULE_1__["default"])(config, _changelog_js__WEBPACK_IMPORTED_MODULE_0__["default"]);
  console.debug('stop migration', migratedConfig);
  return migratedConfig;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migrateFn);

/***/ }),

/***/ "./src/changelog/migration1Fn.js":
/*!***************************************!*\
  !*** ./src/changelog/migration1Fn.js ***!
  \***************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants.js */ "./src/constants.js");

const migration1Fn = async config => {
  config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.firstStart] = true;
  config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.extensionUuid] = crypto.randomUUID();
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migration1Fn);

/***/ }),

/***/ "./src/changelog/migration2Fn.js":
/*!***************************************!*\
  !*** ./src/changelog/migration2Fn.js ***!
  \***************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants.js */ "./src/constants.js");

const migration2Fn = async config => {
  const options = config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.options];
  if (options.length === 1 && options[0].name === undefined) {
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.name] = 'common';
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.commandTemplate] = 'aria2 -c -s4 --max-tries=0 %h %u';
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migration2Fn);

/***/ }),

/***/ "./src/changelog/migration3Fn.js":
/*!***************************************!*\
  !*** ./src/changelog/migration3Fn.js ***!
  \***************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants.js */ "./src/constants.js");

const migration3Fn = async config => {
  const options = config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.options];
  if (options.length === 1 && options[0].name === 'common') {
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.commandTemplate] = 'aria2 -c -s4 -m0 %h %u';
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migration3Fn);

/***/ }),

/***/ "./src/changelog/migration4Fn.js":
/*!***************************************!*\
  !*** ./src/changelog/migration4Fn.js ***!
  \***************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants.js */ "./src/constants.js");

const migration4Fn = async config => {
  const options = config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.options];
  if (options.length === 1 && options[0].name === 'common') {
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.commandTemplate] = 'aria2c -c -s4 -m0 -k1M --stream-piece-selector=inorder --summary-interval=1 --console-log-level=notice %h %u';
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.useDisallowedHeaders] = true;
    options[0][_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].option.disallowedHeaders] = ['Range'];
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migration4Fn);

/***/ }),

/***/ "./src/constants.js":
/*!**************************!*\
  !*** ./src/constants.js ***!
  \**************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const Constants = Object.freeze({
  option: Object.freeze({
    options: 'options',
    firstStart: 'firstStart',
    extensionUuid: 'extensionUuid',
    tabIdUrlParameterName: prefix => `${prefix}tabId`,
    frameIdUrlParameterName: prefix => `${prefix}frameId`,
    urlPattern: 'urlPattern',
    urlPatternFlags: 'urlPatternFlags',
    useHeaders: 'useHeaders',
    name: 'name',
    headerParameterName: 'headerParameterName',
    useAllowedHeaders: 'useAllowedHeaders',
    allowedHeaders: 'allowedHeaders',
    useDisallowedHeaders: 'useDisallowedHeaders',
    disallowedHeaders: 'disallowedHeaders',
    commandTemplate: 'commandTemplate',
    escapeCmdUniversal: {
      escapeCmdUniversal: 'escapeCmdUniversal',
      enabled: 'enabled',
      platforms: 'platforms'
    }
  }),
  messageType: {
    execProbRequest: 'exec-prob-request',
    copyDownloadCommand: 'copy-download-command',
    copyDownloadCommandInBackground: 'copy-download-command-in-background'
  },
  element: Object.freeze({
    contextMenuId: "simple-copy-aria2-download-command",
    config: 'config',
    reset: 'reset',
    save: 'save'
  }),
  changelog: 'changelog'
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Constants);

/***/ }),

/***/ "./src/lib/Option.js":
/*!***************************!*\
  !*** ./src/lib/Option.js ***!
  \***************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Option)
/* harmony export */ });
class Option {
  #config = null;
  #storage = browser.storage.local;
  #defaultConfigPath;
  constructor(defaultConfigPath = '/config.json') {
    this.#defaultConfigPath = defaultConfigPath;
    this.#cacheReset();
  }
  async get() {
    if (!this.#config) {
      this.#config = await this.#storage.get();
      if (!this.#config || Object.keys(this.#config).length < 1) {
        await this.reset();
      }
    }
    return structuredClone(this.#config);
  }
  async save(config) {
    await this.#storage.set(config);
    this.#config = config;
  }
  async reset() {
    const config = await (await fetch(browser.runtime.getURL(this.#defaultConfigPath))).json();
    await this.#storage.set(config);
    this.#config = config;
  }
  #cacheReset() {
    browser.storage.onChanged.addListener(() => this.#config = null);
  }
}

/***/ }),

/***/ "./src/lib/migration/checkOrInitFn.js":
/*!********************************************!*\
  !*** ./src/lib/migration/checkOrInitFn.js ***!
  \********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const checkOrInitFn = (config, migrationScriptName, changelogName) => {
  const configChangelog = config[changelogName];
  if (configChangelog === undefined) {
    config[changelogName] = {};
    return false;
  }
  const configChangelogMigrationScript = configChangelog[migrationScriptName];
  return configChangelogMigrationScript === undefined || configChangelogMigrationScript === false;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (checkOrInitFn);

/***/ }),

/***/ "./src/lib/migration/constants.js":
/*!****************************************!*\
  !*** ./src/lib/migration/constants.js ***!
  \****************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const Constants = Object.freeze({
  changelog: 'changelog'
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Constants);

/***/ }),

/***/ "./src/lib/migration/migration.js":
/*!****************************************!*\
  !*** ./src/lib/migration/migration.js ***!
  \****************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _migrationHelperFn_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./migrationHelperFn.js */ "./src/lib/migration/migrationHelperFn.js");

const startMigrationFn = async (originalConfig, changelog) => {
  const config = {
    ...originalConfig
  };
  console.debug('start migration', {
    changelog,
    config
  });
  for (const {
    name,
    migrationFn
  } of changelog) {
    console.debug('start migration file', {
      config,
      name,
      migrationFn
    });
    await (0,_migrationHelperFn_js__WEBPACK_IMPORTED_MODULE_0__["default"])(config, name, migrationFn);
  }
  console.debug('stop migration', {
    originalConfig,
    config
  });
  return config;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (startMigrationFn);

/***/ }),

/***/ "./src/lib/migration/migrationHelperFn.js":
/*!************************************************!*\
  !*** ./src/lib/migration/migrationHelperFn.js ***!
  \************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants.js */ "./src/lib/migration/constants.js");
/* harmony import */ var _checkOrInitFn_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./checkOrInitFn.js */ "./src/lib/migration/checkOrInitFn.js");


const migrationHelperFn = async (config, migrationScriptName, migrationFn) => {
  if ((0,_checkOrInitFn_js__WEBPACK_IMPORTED_MODULE_1__["default"])(config, migrationScriptName, _constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].changelog)) {
    config[_constants_js__WEBPACK_IMPORTED_MODULE_0__["default"].changelog][migrationScriptName] = true;
    await migrationFn(config);
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (migrationHelperFn);

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!******************************!*\
  !*** ./src/option/option.js ***!
  \******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_Option_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/Option.js */ "./src/lib/Option.js");
/* harmony import */ var _changelog_migrateFn_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../changelog/migrateFn.js */ "./src/changelog/migrateFn.js");


const option = new _lib_Option_js__WEBPACK_IMPORTED_MODULE_0__["default"]();
const init = async () => {
  const saveButton = document.getElementById('saveButton');
  const resetButton = document.getElementById('resetButton');
  const optionText = document.getElementById('optionText');
  const localize = () => {
    saveButton.textContent = browser.i18n.getMessage('save');
    resetButton.textContent = browser.i18n.getMessage('reset');
    document.title = browser.i18n.getMessage('optionsTitle');
  };
  const loadOptions = async () => {
    optionText.value = JSON.stringify(await option.get(), null, "\t");
  };
  const saveOptions = () => {
    try {
      option.save(JSON.parse(optionText.value));
    } catch (e) {
      alert(`${browser.i18n.getMessage('optionsFormatError')}: ${e}`);
    }
  };
  const resetOptions = async () => {
    await option.reset();
    const config = await (0,_changelog_migrateFn_js__WEBPACK_IMPORTED_MODULE_1__["default"])(await option.get());
    await option.save(config);
    await loadOptions();
  };
  saveButton.addEventListener('click', () => saveOptions());
  resetButton.addEventListener('click', () => resetOptions());
  localize();
  await loadOptions();
};
document.addEventListener('DOMContentLoaded', () => init());
})();

/******/ })()
;
//# sourceMappingURL=option.js.map